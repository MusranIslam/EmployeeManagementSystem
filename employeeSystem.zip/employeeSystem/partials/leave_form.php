<?php

    echo '$emp_id ___ $month_id';

?>